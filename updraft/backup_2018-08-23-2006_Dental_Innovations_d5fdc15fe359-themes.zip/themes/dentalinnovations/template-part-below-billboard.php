<div class="below-billboard">

    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Below Billboard Section') ) : ?>
    <?php endif; ?>

</div>