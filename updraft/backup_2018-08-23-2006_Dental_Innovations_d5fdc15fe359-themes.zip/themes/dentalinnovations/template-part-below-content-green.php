<div class="below-content-green">
<div class="below-content-green-inner">
    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Below Content Green Section') ) : ?>
    <?php endif; ?>
</div>
</div>