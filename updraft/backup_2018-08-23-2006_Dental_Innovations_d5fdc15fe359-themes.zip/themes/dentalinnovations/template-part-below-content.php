<div class="below-content">
<div class="below-content-inner">
    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Below Content Section') ) : ?>
    <?php endif; ?>
</div>
</div>