<div class="billboard">

    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Billboard Section') ) : ?>
    <?php endif; ?>

</div>