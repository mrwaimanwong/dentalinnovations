<div class="content-section">
<div class="content-section-inner">
    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Content Section') ) : ?>
    <?php endif; ?>
</div>
</div>